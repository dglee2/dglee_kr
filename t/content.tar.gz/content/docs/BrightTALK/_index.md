---
weight: 1
bookFlatSection: true
title: "BrightTALK"
---

# 웨비나 리뷰 / 코멘트

## Bright Talk.

들어볼만한 여러가지 채널이 있다. 한시간 들으면 1 CPE.
아마도... CPE 올리기 가장 무식하고 쉬운방법이 아닐까... 생각함.
1시간 중 40분인가... 들으면, 그러니까.. 재생을 하면(Play만 시켜놓고 딴짓해도 됨..),
1 CPE 인정.

따로 CPE 승인신청 하지 않아도 되고, 정말 미안하리만큼... 허무하게 CPE 올리는 방법.
